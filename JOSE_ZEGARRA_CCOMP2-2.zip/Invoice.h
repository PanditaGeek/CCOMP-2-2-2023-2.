#include <iostream>
#include <string>
using namespace std;

class Invoice {
private:
    string objeto;
    string descripcion;
    int cantidad;
    int precio;
    double tax;
    double descuento;

public:
    Invoice(string _objeto, string _descripcion, int _cantidad, int _precio, double _tax = 0.20, double _descuento = 0) {
        objeto = _objeto; 
        descripcion = _descripcion;
        cantidad = _cantidad;
        precio = _precio;
        tax = _tax;
        descuento = _descuento;
    }

    string getObjeto() {
        return objeto;
    }

    void setObjeto(string _objeto) {
        objeto = _objeto;
    }

    string getDescripcion() {
        return descripcion ;
    }

    void setDescripcion(string _descripcion) {
         descripcion = _descripcion ;
    }

    int getCantidad () {
        return cantidad ;
    }

    void setCantidad(int _cantidad ) {
         cantidad = _cantidad;
    }

    int getPrecio () {
        return precio ;
    }

    void setPrecio (int _precio ) {
         precio = _precio;
    }

    double getTax () {
        return tax ;
    }

    void setTax (double _tax ) {
         tax = _tax;
    }

    double getDescuento(){
        return descuento;
    }
    void setDescuento(double _descuento){
      descuento = _descuento;
    }

    double getInvoiceAmount() {
    
        if (cantidad < 0) {
        cantidad = 0; 
        }
        if (precio < 0) {
        precio = 0; 
        }
    
        double importe = cantidad * precio;
    
        importe += importe * tax;
    
        return importe;
    }

};
