#include "Date.h"

int main() {
	Date fechas(9, 5, 2003);
	fechas.Fechas();
}
