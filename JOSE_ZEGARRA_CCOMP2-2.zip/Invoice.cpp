#include <iostream>
#include <string>
#include "Invoice.h"
using namespace std;

int main() {
    
    Invoice factura1("Producto1", "Descripción1", 5, 10);

    double importe = factura1.getInvoiceAmount();
    cout << "El importe de la factura es: " << importe << endl;

    return 0;
}