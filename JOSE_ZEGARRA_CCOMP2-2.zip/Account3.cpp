#include <string>
#include <iostream>
#include "Account3.h"
using namespace std;


int main()
{
    Account3 account3{7220, "Jose", "Zegarra", 500.2};
    cout << "Hola";
}