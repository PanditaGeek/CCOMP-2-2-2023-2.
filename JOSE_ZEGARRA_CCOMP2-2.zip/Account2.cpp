#include <string>
#include <iostream>
#include "Account2.h"
using namespace std;


int main()
{
    Account2 account1{ "Jane Green", 50 };
    Account2 account2{ "John Blue", -7 };

    account1.displayAccount();
    account2.displayAccount();

    cout << "\n\nEnter deposit amount for account1: ";
    int depositAmount;
    cin >> depositAmount;
    cout << "adding " << depositAmount << " to account1 balance";
    account1.deposit(depositAmount);

    account1.displayAccount();
    account2.displayAccount();
  
    cout << "\n\nEnter deposit amount for account2: ";
    cin >> depositAmount;
    cout << "adding " << depositAmount << " to account2 balance";
    account2.deposit(depositAmount);

    account1.displayAccount();
    account2.displayAccount();

    cout << "Inserte monto de retiro para la primera cuenta: ";
    int ret;
    cin >> ret;
    account1.withdraw1(ret);
    cout << "Inserte monto de retiro para la segunda cuenta: ";
    cin >> ret;
    account2.withdraw1(ret);
}