#include "MotorVehicle.h"
#include <string>
#include <iostream>
using namespace std;

int main() {
  string marca, energia, color, año, string;
  int motor;
    MotorVehicle carro("Kia", "Petroleo", "2014", "Rojo", 2000);
    cout << "Ingrese marca del vehículo: ";
    cin>> marca;
    cout << "Ingrese tipo de energía del vehículo: ";
    cin >> energia;
    cout << "Ingrese año del vehículo: ";
    cin >> año;
    cout << "Ingrese color del vehículo: ";
    cin >> color;
    cout << "Ingrese capacidad del motor del vehículo: ";
    cin >> motor;
    MotorVehicle carro1(marca, energia, año, color, motor);

    cout << "\nCaracterísticas del primer vehículo\n";
    carro.info_carro(); 
    cout << "\nCaracterísticas del segundo vehículo\n";
    carro1.info_carro();
}