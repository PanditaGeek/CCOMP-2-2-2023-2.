#include <iostream>
using namespace std;

int main() {
  int n1, n2, n3;

  cout << "Ingrese primer número: " << endl;
  cin >> n1;

  cout << "Ingrese segundo número: " << endl;
  cin >> n2;

  cout << "Ingrese tercer número: " << endl;
  cin >> n3;

  if ((n3 % n1 == 0) && (n3 % n2 == 0)) {
    cout << "Los dos primeros números son factores del tercero" << endl;
  } else
    cout << "Uno o ninguno de los primeros dos números ingresados no son "
            "factores de "
         << n3 << endl;
  return 0;
}