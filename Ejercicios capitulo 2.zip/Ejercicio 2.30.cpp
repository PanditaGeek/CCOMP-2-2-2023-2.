#include <iostream>
using namespace std;

int main(){

  char i;
  float pd, ht, kg, alt;
  
  cout << "¿Usará métrica de E (Estados Unidos) o la G (Global)?" << endl;
  cin >> i;

  int n = static_cast<int>(i);
  
  if(n == 69){

    cout << "Ingrese peso: ";
    cin >> pd;
    cout << "Ingrese altura: ";
    cin >> ht;
    
    float BMI = (pd * 703)/(ht*ht);

    cout << "\nEl resultado de su BMI es: " << BMI << endl;
    
  }

  if(n == 71){

  cout << "Ingrese peso: ";
  cin >> kg; 
  cout << "Ingrese altura en metros: ";
  cin >> alt;

  float BMI = kg/(alt*alt);

  cout << "El resultado de su BMI es: " << BMI << endl;
    
  }

  cout << "\nVALORES DEL BMI\nBajo de peso:\tMenor que 18.5.\nNormal:\tEntre 18,5 y 24.9.\nSobrepeso:\tEntre 25 y 29.9.\nObeso:\t30 a más. ";
  
  return 0;
}