#include <iostream>
using namespace std;

int main() {
  int r, d, c, a;
  float pi = 3.14159;
  cout << "Ingrese radio: " << endl;
  cin >> r;

  d = 2*r;
  c = 2*pi*r;
  a = pi*(r*r);
  
  cout << "El diametro es: " << d << endl;
  cout << "La circunferencia es: " << c << endl;
  cout << "El área es: " << a << endl;
  
  return 0;
}