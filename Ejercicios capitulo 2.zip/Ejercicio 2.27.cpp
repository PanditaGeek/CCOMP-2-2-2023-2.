#include <iostream>
using namespace std; 

int main() {

  char n;
  cout << "Ingrese solo un símbolo: " << endl;
  cin >> n;

  int cs = static_cast<int>(n);
  cout << "El valor numérico del primer símbolo ingresado es: " << cs;
  
}