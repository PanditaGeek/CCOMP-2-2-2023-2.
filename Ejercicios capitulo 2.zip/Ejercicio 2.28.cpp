#include <iostream>
using namespace std;

int main(){
  
  int num;
  cout << "Ingrese un número de 4 digitos: ";
  cin >> num;

  int n1, n2, n3, n4;
  
  n1 = num%10;
  n2 = ((num%100) - n1)/10;    
  n3 = (num%1000)/100;
  n4 = num/1000;
  
  cout << n1 << "  " << n2 << "  " << n3 << "  " << n4;

  return 0;
}