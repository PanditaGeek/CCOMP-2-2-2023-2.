#include <iostream>
using namespace std;

int main() {
  int n1, n2, n3, n4, n5;
  
  cout <<"Ingrese prime número: "<< endl;
  cin >> n1;
  cout <<"Ingrese segundo número: "<< endl;
  cin >> n2;
  cout <<"Ingrese tercer número: "<< endl;
  cin >> n3;
  cout <<"Ingrese cuarto número: "<< endl;
  cin >> n4;
  cout <<"Ingrese quinto número: "<< endl;
  cin >> n5;

  if(n1 < n2 && n1 < n3 && n1 < n4 && n1 < n5){
    cout << "El menor número es: " << n1 << endl;
  }
  if(n2 < n1 && n2 < n3 && n2 < n4 && n2 < n5){
    cout << "El menor número es: " << n2 << endl;
  }
  if(n3 < n2 && n3 < n1 && n3 < n4 && n3 < n5){
    cout << "El menor número es: " << n3 << endl;
  }
  if(n4 < n2 && n4 < n3 && n4 < n1 && n4 < n5){
    cout << "El menor número es: " << n4 << endl;
  }
  if(n5 < n2 && n5 < n3 && n5 < n4 && n5 < n1){
    cout << "El menor número es: " << n5 << endl;
  }

  
  if(n1 > n2 && n1 > n3 && n1 > n4 && n1 > n5){
    cout << "El mayor número es: " << n1 << endl;
  }
  if(n2 > n1 && n2 > n3 && n2 > n4 && n2 > n5){
    cout << "El mayor número es: " << n2 << endl;
  }
  if(n3 > n2 && n3 > n1 && n3 > n4 && n3 > n5){
    cout << "El mayor número es: " << n3 << endl;
  }
  if(n4 > n2 && n4 > n3 && n4 > n1 && n4 > n5){
    cout << "El mayor número es: " << n4 << endl;
  }
  if(n5 > n2 && n5 > n3 && n5 > n4 && n5 > n1){
    cout << "El mayor número es: " << n5 << endl;
  }
 
  return 0;
}