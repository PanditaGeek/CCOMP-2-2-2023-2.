#include <iostream>
using namespace std;

int main() {

  string a = "* * * * * * * *";
  string b = " * * * * * * * *";

  cout << a << "\n" << b << "\n" << a << "\n" << b << "\n" << a << "\n" << b << "\n" << a << "\n" << b  << endl;
  return 0;
}