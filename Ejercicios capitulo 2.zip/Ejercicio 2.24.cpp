#include <iostream>
using namespace std;

int main() {
  int n1, n2, suma;

  cout << "Ingrese primer número: " << endl;
  cin >> n1;

  cout << "Ingrese segundo número: " << endl;
  cin >> n2;

  suma = n1+ n2;

  if(suma % 2 == 0){
    cout << "La suma de los números es par" << endl;
  }
  else
    cout << "La suma de los número es impar" << endl;
  
  return 0;
}